from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from infrastructure.databases.base import Base

class UserModel(Base):
    __tablename__ = 'users'
    __table_args__ = {'extend_existing': True}  # Cho phép ghi đè nếu đã khai báo trước

    UserId = Column(Integer, primary_key=True, autoincrement=True)
    UserName = Column(String(50), nullable=False)
    Password = Column(String(255), nullable=False)
    Email = Column(String(100), nullable=False, unique=True)
    Status = Column(String(20))
    Create_Date = Column(DateTime)
    Date_Of_Birth = Column(DateTime)
    Phone_Number = Column(String(15))
    RoleID = Column(Integer, ForeignKey('roles.RoleID'))
