from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey
from infrastructure.databases.base import Base

class TicketModel(Base):
    __tablename__ = 'ticket'
    __table_args__ = {'extend_existing': True}  # Cho phép ghi đè nếu đã tồn tại

    TicketID = Column(Integer, primary_key=True, autoincrement=True)
    EventName = Column(String(100), nullable=False)
    EventDate = Column(DateTime, nullable=False)
    Price = Column(Float, nullable=False)
    Status = Column(String(20))
    OwnerID = Column(Integer, ForeignKey('users.UserId'))

